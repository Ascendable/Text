import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagement {
    public static void main(String[] args) {
        ArrayList<Student> list = new ArrayList<>();
        Student s1 = new Student("2020", "小梦", "男", "18", "A");
        Student s2 = new Student("2021", "小优", "女", "18", "A");
        Student s3 = new Student("2022", "萌德", "男", "19", "B");
        Student s4 = new Student("2023", "小草", "女", "18", "C");
        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(s4);
        while(true){
            System.out.println("----------学生管理系统----------");
            System.out.println("1.添加学生");
            System.out.println("2.删除学生");
            System.out.println("3.修改学生属性");
            System.out.println("4.查看所有学生");
            System.out.println("5.根据学号查询学生");
            System.out.println("6.根据性别显示等级");
            System.out.println("7.通过等级显示学生");
            System.out.println("8.退出");
            Scanner i = new Scanner(System.in);
            String line = i.nextLine();
            switch (line){
                case "1":
                    addstudent(list);
                    break;
                case "2":
                    remove(list);
                    break;
                case "3":
                    modify(list);
                    break;
                case "4":
                    findstudent(list);
                    break;
                case "5":
                    findstubyid(list);
                    break;
                case "6":
                    showRanksbygender(list);
                    break;
                case "7":
                    showStubyRanks(list);
                case "8":
                    System.out.println("谢谢使用！");
                    System.exit(0);
            }
        }
    }
    //添加学生
    public static void addstudent(ArrayList<Student> list){
        int q = 0;//查重
        Scanner m = new Scanner(System.in);
        System.out.println("请输入学号（三到四位数）:");
        String id = m.nextLine();
        for(int i=0;i<list.size();i++){
            Student stu = list.get(i);
            if(stu.getId().equals(id)){
                System.out.println("输入的学号有重复，请重新输入");
                q++;
                break;
            }
        }
        if(q==0){
            System.out.println("请输入姓名");
            String name = m.nextLine();
            System.out.println("请输入性别(男或女)");
            String gender = m.nextLine();
            System.out.println("请输入年龄");
            String age = m.nextLine();
            System.out.println("请输入等级（A或B或C）");
            String rank = m.nextLine();
            Student s = new Student();
            s.setId(id);
            s.setName(name);
            s.setGender(gender);
            s.setAge(age);
            s.setRank(rank);
            list.add(s);
            System.out.println("添加学生成功");
        }
    }
    //删除学生
    public static void remove(ArrayList<Student> list){
        Scanner id = new Scanner(System.in);
        System.out.println("请输入要删除学生的学号");
        for(int i = 0;i<list.size();i++){
            Student s = list.get(i);
            if(s.getId().equals(id)){
                list.remove(i);
                System.out.println("删除学生成功");
                break;
            }else if(i==list.size()){
                System.out.println("未找到该学生，请检查学号是否正确");
                remove(list);
            }
        }
    }


    //修改学生属性
    public static void modify(ArrayList<Student> list){
        Scanner m = new Scanner(System.in);
        System.out.println("请输入要修改学生的学号");
        String id = m.nextLine();
        for(int i=0;i<list.size();i++){
            Student s =list.get(i);
            if(s.getId().equals(id)){
                System.out.println("请输入要修改的内容");
                System.out.println("1 学号");
                System.out.println("2 姓名");
                System.out.println("3 性别");
                System.out.println("4 年龄");
                System.out.println("5 等级");
                String q = m.nextLine();
                System.out.println("请输入修改后内容：");
                String n = m.nextLine();
                switch(q){
                    case "1":s.setId(n);
                        System.out.println("修改成功！");
                        break;
                    case "2":s.setName(n);
                        System.out.println("修改成功！");
                        break;
                    case "3":s.setGender(n);
                        System.out.println("修改成功！");
                        break;
                    case "4":s.setAge(n);
                        System.out.println("修改成功！");
                        break;
                    case "5":s.setRank(n);
                        System.out.println("修改成功！");
                        break;

                }
                break;
            }
            else if (i==list.size()-1)
            {
                System.out.println("没有找到该学生，请检查学号是否错误！");
                modify(list);
            }
        }

    }
    //查看所有学生
    public static void findstudent(ArrayList<Student> list){
        if(list.size()==0){
            System.out.println("没有学生被添加！");
        }else {
            System.out.println("学号  姓名 性别 年龄 等级");
            for(int i=0;i<list.size();i++){
                Student s = list.get(i);
                System.out.println(s.getId()+" "+s.getName()+"  "+s.getGender()+"   "+s.getAge()+"   "+s.getRank());

            }
        }

    }


    //根据学号查询学生
    public static void findstubyid(ArrayList<Student> list){
        Scanner m = new Scanner(System.in);
        System.out.println("请输入某学生的学号");
        String id = m.nextLine();
        for (int i=0;i<list.size();i++){
            Student s = list.get(i);
            if (s.getId().equals(id)){
                System.out.println("姓名:"+s.getName()+ " 性别:"+s.getGender()+" 年龄:"+s.getAge()+" 等级:"+s.getRank());
            }else if (i==list.size()){
                System.out.println("没有找到该学生，请检查学号是否错误！");
                findstubyid(list);
            }
        }
    }

    //根据性别显示等级
    public static void showRanksbygender(ArrayList<Student> list){
        Scanner m = new Scanner(System.in);
        System.out.println("请输入男or女:");
        String gender = m.nextLine();
        for (int i=0;i<list.size();i++) {
            Student s = list.get(i);
            if (s.getGender().equals(gender)){
                System.out.println("姓名："+s.getName()+" 等级："+s.getRank());
            }else if(i==list.size()){
                System.out.println("未找到！");
            }
        }
    }

    //通过等级显示学生姓名
    public static void showStubyRanks(ArrayList<Student> list){
        Scanner m = new Scanner(System.in);
        System.out.println("请输入一个等级（A或B或C）：");
        String rank = m.nextLine();
        System.out.print("等级为"+rank+"的学生有：");
        for (int i=0;i<list.size();i++){
            Student s = list.get(i);
            if(s.getRank().equals(rank)){
                System.out.print(s.getName());
            }else if(i==list.size()){
                System.out.println("未找到！");
            }
        }
    }




}
